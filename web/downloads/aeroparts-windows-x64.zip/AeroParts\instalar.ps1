﻿$ErrorActionPreference = 'Stop'
$Src  = $PSScriptRoot
$Dest = Join-Path $env:LOCALAPPDATA 'AeroParts'
if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
Copy-Item $Src $Dest -Recurse
$Shell = New-Object -ComObject WScript.Shell
foreach ($Dir in @([Environment]::GetFolderPath('Desktop'),
                   (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))) {
  $Link = $Shell.CreateShortcut((Join-Path $Dir 'AeroParts.lnk'))
  $Link.TargetPath = Join-Path $Dest 'AeroParts.exe'
  $Link.WorkingDirectory = $Dest
  $Link.IconLocation = Join-Path $Dest 'AeroParts.ico'
  $Link.Description = 'Inventario de repuestos aeronauticos'
  $Link.Save()
}
Write-Host 'AeroParts instalado. Abrelo desde el Escritorio o el menu Inicio.'
