@echo off
rem Doble clic para instalar AeroParts (sin permisos de administrador).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
pause
