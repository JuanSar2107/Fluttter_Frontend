#!/usr/bin/env bash
APP_ID="com.aeroparts.aviation_inventory"
rm -rf "$HOME/.local/share/aeroparts"
rm -f "$HOME/.local/share/applications/$APP_ID.desktop" \
      "$HOME/.local/share/icons/hicolor/512x512/apps/$APP_ID.png"
echo "AeroParts desinstalado."
