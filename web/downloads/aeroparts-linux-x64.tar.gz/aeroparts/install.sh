#!/usr/bin/env bash
# Instala AeroParts para el usuario actual (sin sudo) y lo agrega al menu.
set -euo pipefail
APP_ID="com.aeroparts.aviation_inventory"
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/aeroparts"

rm -rf "$DEST"
mkdir -p "$DEST" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/512x512/apps"
cp -r "$SRC/." "$DEST/"
cp "$SRC/aeroparts.png" "$HOME/.local/share/icons/hicolor/512x512/apps/$APP_ID.png"

cat > "$HOME/.local/share/applications/$APP_ID.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=AeroParts
Comment=Inventario de repuestos aeronauticos
Exec=$DEST/aeroparts
Icon=$APP_ID
Terminal=false
Categories=Office;
StartupWMClass=$APP_ID
DESKTOP

update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
echo "AeroParts instalado. Buscalo en el menu de aplicaciones."
